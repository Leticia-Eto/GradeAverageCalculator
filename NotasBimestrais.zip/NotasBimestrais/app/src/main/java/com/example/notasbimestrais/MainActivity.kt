package com.example.notasbimestrais

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import kotlin.random.Random

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
        val btn_media= findViewById<Button>(R.id.btn_media)
        btn_media.setOnClickListener {
            media();
        }
    }
    fun media(){
        val tv_resultado = findViewById<TextView>(R.id.tv_total)
        val nota1=findViewById<EditText>(R.id.edit_nota1).getText().toString().toDouble()
        val nota2=findViewById<EditText>(R.id.edit_nota2).getText().toString().toDouble()
        val nota3=findViewById<EditText>(R.id.edit_nota3).getText().toString().toDouble()
        val nota4=findViewById<EditText>(R.id.edit_nota4).getText().toString().toDouble()
        val total= ((nota1+nota2+nota3+nota4)/4)
        tv_resultado.setText("Total: ${total} ")


    }
}